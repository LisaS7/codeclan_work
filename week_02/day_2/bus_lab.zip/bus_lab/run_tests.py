import unittest
from tests.bus_test import TestBus
from tests.bus_stop_test import TestBusStop
from tests.person_test import TestPerson

if __name__ == '__main__':
    unittest.main()
