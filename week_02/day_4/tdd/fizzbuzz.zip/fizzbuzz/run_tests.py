import unittest
from tests.test_fizzbuzz import TestFizzBuzz

if __name__ == "__main__":
    unittest.main()
